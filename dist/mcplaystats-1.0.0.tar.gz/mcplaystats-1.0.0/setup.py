from setuptools import find_packages, setup
setup(
    name='mcplaystats',
    packages=find_packages(),
    version='1.0.0',
    description='Unofficial API Wrapper for McPlayHD API',
    author='Mythological',
    license='MIT',
    install_requires=[],
)
